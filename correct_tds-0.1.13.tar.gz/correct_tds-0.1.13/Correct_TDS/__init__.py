### Init file for correct TDS

__version__ = "0.1.13"
__author__ = 'PERETTI Romain'
__credits__ = 'IEMN National Laboratory'