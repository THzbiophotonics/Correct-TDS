from setuptools import setup

setup(
    name='Correct_TDS_Sami',
    version='0.2.1',    
    description='working correct TDS software by Le Guilcher Sami',
    url='https://github.com/THzbiophotonics/Correct-TDS-in-development/tree/Sami',
    author='Le Guilcher Sami',
    author_email='sami.leguil@gmail.com',
    license='IEMN',
    packages=['Correct_TDS_Sami'],
    install_requires=['mpi4py>=2.0',
                      'numpy',                     
                      ],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: BSD License',  
        'Operating System :: POSIX :: Linux',        
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
    ],
)