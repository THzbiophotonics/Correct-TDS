### Init file for correct TDS Sami

__version__ = "0.2.1"
__author__ = 'Le Guilcher Sami'
__credits__ = 'IEMN National Laboratory'