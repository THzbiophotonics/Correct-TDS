### Init file for correct TDS Sami

__version__ = "0.3.3"
__author__ = 'Le Guilcher Sami'
__credits__ = 'IEMN National Laboratory'